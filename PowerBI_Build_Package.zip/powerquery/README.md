# Power BI Build Package — E&O Reporting

This folder contains ready-to-paste **Power Query (M)** scripts and a **DAX measures** file
to set up the full data model described in the approach guide.

## Files & Order of Setup

| Step | File | What it creates |
|---|---|---|
| 1 | `01_Fact_EO.pq` | Fact table — combines all monthly entity CSVs from a folder |
| 2 | `02_Dim_Entity.pq` | Dimension table from `Entity Mapping.xlsx` (Region/Cluster/Country/Entity) |
| 3 | `03_Dim_Product.pq` | Dimension table from `Product Hierarchy.xlsb` (Business Unit/Segment/Brand/SKU) |
| 4 | `04_Dim_Calendar.pq` | Slimmed date table from `Calendar Tbl.xlsx` (83 → 9 columns) |
| 5 | `05_Type_Filter.pq` | Disconnected slicer table for Excess/Obsolete/Both |
| 6 | `06_DAX_Measures.txt` | All DAX measures — paste each into a new "Measures" table |

## How to Use Each .pq File

1. In Power BI Desktop: **Home → Get Data → Blank Query**
2. Right-click the new query → **Advanced Editor**
3. Delete the placeholder text, paste the full contents of the `.pq` file
4. **Edit the file path / folder path** at the top of the script (marked `<-- CHANGE THIS`)
5. Click **Done**, then rename the query (right panel) to match the table name in the comments
   (e.g., `Fact_EO`, `Dim_Entity`, `Dim_Product`, `Dim_Calendar`, `Type_Filter`)
6. Click **Close & Apply**

## After Loading All Tables

1. Go to **Model view**
2. Create relationships:
   - `Dim_Entity[Entity Code]` (1) → `Fact_EO[Entity Code]` (many)
   - `Dim_Product[SKU]` (1) → `Fact_EO[SKU]` (many)
   - `Dim_Calendar[Date]` (1) → `Fact_EO` — you'll need a `Date` column in Fact_EO.
     **Quickest fix**: add a calculated column in Fact_EO:
     `Date = DATE ( Fact_EO[Year], Fact_EO[Period], 1 )`
     then relate `Dim_Calendar[Date]` → `Fact_EO[Date]`
3. Right-click `Dim_Calendar` → **Mark as date table** → select `Date` column
4. Build the two hierarchies (drag-and-drop in Model view):
   - On `Dim_Entity`: Region → Cluster → Country
   - On `Dim_Product`: BUSINESS_UNIT → SEGMENT → BRAND_FAMILY
5. Create a new blank table called `Measures` (Modeling → New Table → `Measures = ROW("x",0)`),
   then add each measure from `06_DAX_Measures.txt` as a new measure on that table.

## Testing with Sample Data

Point `01_Fact_EO.pq`'s `FolderPath` at the `monthly_files/` folder from
`Sample_Data_Package.zip` (shared earlier) to validate the whole pipeline
end-to-end before your real monthly files arrive.

## Notes
- The `Type_Filter` table is intentionally **disconnected** (no relationship)
  — it's read via `SELECTEDVALUE()` inside DAX measures (see `06_DAX_Measures.txt`,
  section 2). This is the recommended pattern for "what-if"-style slicers that
  shouldn't filter the model directly.
- Adjust sheet names in `03_Dim_Product.pq` and `04_Dim_Calendar.pq` if your
  actual workbook uses a different sheet name than `Sheet1`.
